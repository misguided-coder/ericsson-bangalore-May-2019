package com.example.facade;

public class BranchOperations {
	
	CustomerService customerService = new CustomerService();
	AccountService savingAccountService = new SavingAccountService();
	AccountService currentAccountService = new CurrentAccountService();
	BranchService branchService = new BranchService();
	EmailService emailService = new EmailService();
	SMSService smsService = new SMSService();
	
	public void openAccount() {
		//tx begin
		customerService.updateEmail();
		customerService.updatePhone();
		branchService.open(savingAccountService);
		emailService.send();
		smsService.send();
		//tx commit
	}

	public void closeAccount() {
		
	}
	
	public void transferFunds() {
		savingAccountService.withdraw();
		savingAccountService.deposit();
		emailService.send();
		emailService.send();
		smsService.send();
		smsService.send();
	}

}
