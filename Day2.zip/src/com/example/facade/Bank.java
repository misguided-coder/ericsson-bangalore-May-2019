package com.example.facade;

public class Bank {

	public static void main(String[] args) {
		
		BranchOperations branchOperations = new BranchOperations();
		
		branchOperations.openAccount();
		
		branchOperations.transferFunds();
		
		branchOperations.closeAccount();
		
		/*CustomerService customerService = new CustomerService();
		AccountService accountService = new SavingAccountService();
		BranchService branchService = new BranchService();
		EmailService emailService = new EmailService();
		SMSService smsService = new SMSService();
		
		customerService.updateEmail();
		customerService.updatePhone();
		branchService.open(accountService);
		emailService.send();
		smsService.send();*/
		
		
	}
}
