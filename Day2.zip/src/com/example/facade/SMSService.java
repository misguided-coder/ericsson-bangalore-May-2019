package com.example.facade;

public class SMSService {

	public void send() {
		System.out.println("Notification sent to customer using Mobile SMS....");
	}
	
}
