package com.example.adapter;

public class MP3MusicPlayer implements MusicPlayer {

	public void playSong(String mediaName) {
		System.out.printf("MP3MusicPlayer =====>  playing %s song!!!!%n",mediaName);
	}
	
	public void stop() {
		System.out.println("MP3MusicPlayer =====>  stopping song!!!!");
	}

}
