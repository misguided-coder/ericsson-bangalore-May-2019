package com.example.singleton.dynamic;

public class MultiThreadClient {
	
	public static void main(String[] args) {
		new MultiThreadClient();
	}
	
	public MultiThreadClient() {
		new Thread(new TaskA()).start();
		new Thread(new TaskB()).start();
	}
}


class TaskA implements Runnable {
	@Override
	public void run() {
		Graphics graphics = Graphics.instance();
		graphics.drawLine();
	}
}

class TaskB implements Runnable {
	@Override
	public void run() {
		Graphics graphics = Graphics.instance();
		graphics.drawCircle();
		graphics.drawSquare();
	}
}
