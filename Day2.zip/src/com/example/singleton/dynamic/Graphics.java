package com.example.singleton.dynamic;

//Dynamic way of creating Singleton
//Lazy singleton creation
public class Graphics {

	private static Graphics graphics = null;

	private Graphics() {
	}

	public synchronized static Graphics instance() {
		if (graphics == null) {
			graphics = new Graphics();
		}
		return graphics;
	}

	public void drawLine() {
		System.out.println("Drawing Lines!!!!");
	}

	public void drawCircle() {
		System.out.println("Drawing Circles!!!!");
	}

	public void drawSquare() {
		System.out.println("Drawing Squares!!!!");
	}

}
