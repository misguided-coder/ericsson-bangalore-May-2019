package com.example.factory._3;

public class Client {
	
	public static void main(String[] args) {
		
		Employee employee = ObjectFactory.createEmployee();		
		System.out.println(employee);
		
		Laptop laptop = ObjectFactory.createLaptop();
		System.out.println(laptop);
		
		Car car = ObjectFactory.createCar();		
		System.out.println(car);
		
	}

}
