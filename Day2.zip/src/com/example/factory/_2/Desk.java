package com.example.factory._2;

public class Desk extends Furniture {

	@Override
	public void make() {
		System.out.printf("Desk is made of %s%n",this.material);
	}
	
	@Override
	public void paint() {
		System.out.println("Desk is painted by machine!!!");
	}
	
	@Override
	public void sell() {
		System.out.println("Desk is sold - Rs. 6000000 only!!!!");
		
	}
	
}
