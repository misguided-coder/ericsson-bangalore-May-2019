package com.example.factory._2;

public class FurnitureFactory {
	
	public static Furniture create(char type) {
		Furniture furniture = null;
		switch(type) {
			case 'C':
				furniture = new Chair();	
				break;
			case 'D':
				furniture = new Desk();	
				break;
			case 'A':
				furniture = new Almirah();	
				break;
		}
		return furniture;
	}

}
