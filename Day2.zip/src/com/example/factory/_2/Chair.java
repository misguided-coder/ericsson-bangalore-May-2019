package com.example.factory._2;

public class Chair extends Furniture {

	@Override
	public void make() {
		System.out.printf("Chair is made of %s%n",this.material);
	}
	
	@Override
	public void paint() {
		System.out.println("Chair is painted by hand brush!!!");
	}
	
	@Override
	public void sell() {
		System.out.println("Chair is sold - Rs. 20000000 only!!!!");
		
	}
	
}
