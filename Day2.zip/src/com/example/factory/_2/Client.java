package com.example.factory._2;

public class Client {
	
	public static void main(String[] args) {
		
		//Furniture furniture1 = new Chair();
		Furniture furniture1 = FurnitureFactory.create('C');
		furniture1.info();
		furniture1.make();
		furniture1.paint();
		furniture1.sell();
		
		//Furniture furniture2 = new Desk();
		Furniture furniture2 = FurnitureFactory.create('D');
		furniture2.info();
		furniture2.make();
		furniture2.paint();
		furniture2.sell();
	
		Furniture furniture3 = FurnitureFactory.create('A');
		furniture3.info();
		furniture3.make();
		furniture3.paint();
		furniture3.sell();
	
	}

}
