package com.example.factory._1;

public class Laptop {

	String serialNo;
	String make;
	String model;
	double price;

	public Laptop() {
	}

	public Laptop(String serialNo, String make, String model, double price) {
		this.serialNo = serialNo;
		this.make = make;
		this.model = model;
		this.price = price;
	}

	public String getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Laptop [serialNo=" + serialNo + ", make=" + make + ", model=" + model + ", price=" + price + "]";
	}

}
