package com.example.factory._1;

public class Client {
	
	public static void main(String[] args) {
		
		//Laptop laptop1 = new Laptop("RE34Y6","Dell","Inspiron",70000.00);
		Laptop laptop1 = LaptopFactory.createInstance();
		System.out.println(laptop1);
		
		//Laptop laptop2 = new Laptop("RE34Y6","Dell","Inspiron",70000.00);
		Laptop laptop2 = LaptopFactory.createInstance();
		System.out.println(laptop2);
		
	}

}
