package com.example.factory._abstract;

public class LuxuryCar extends Car {
	
	public LuxuryCar(String location) {
		super(location);
		System.out.printf("LuxuryCar is available in : %s%n",this.location);
	}
	
	@Override
	public void speedUp() {
		System.out.println("LuxuryCar is speeding up!!!!");
	}

	@Override
	public void speedDown() {
		System.out.println("LuxuryCar is slowing down!!!!");
	}
}
