package com.example.factory._abstract;

public class Client {
	
	public static void main(String[] args) {
		
		Car car = CarFactory.createCar(CarType.LUXURY, "Pune");
		car.speedUp();
		car.speedDown();
		
		car = CarFactory.createCar(CarType.LUXURY, "Calcutta");
		car.speedUp();
		car.speedDown();
		
	}

}
