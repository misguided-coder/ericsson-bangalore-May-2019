package com.example.decorator;

public class OnionToppings extends Pizza {

	Pizza originalPizaa;

	public OnionToppings(Pizza originalPizaa) {
		this.originalPizaa = originalPizaa;
	}

	@Override
	public String prepare() {
		return this.originalPizaa.prepare() + addOnions();
	}
	
	public String addOnions() {
		return " with Onions";
	}
}
