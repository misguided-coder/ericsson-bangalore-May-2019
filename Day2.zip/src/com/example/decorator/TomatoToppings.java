package com.example.decorator;

public class TomatoToppings extends Pizza {

	Pizza originalPizaa;

	public TomatoToppings(Pizza originalPizaa) {
		this.originalPizaa = originalPizaa;
	}

	@Override
	public String prepare() {
		return this.originalPizaa.prepare() + addTomatos();
	}
	
	public String addTomatos() {
		return " with Tomatos";
	}
}
