package com.example.decorator;

public class ThinCrustPizza extends Pizza {

	@Override
	public String prepare() {
		return super.prepare() + " with ThinCrust Base";
	}
}
