package com.example.singleton._static._1;

//Static way of creating Singleton
//Eager singleton creation
public class Graphics {

	private static Graphics graphics = new Graphics();

	private Graphics() {
	}

	public static Graphics instance() {
		return graphics;
	}

	public void drawLine() {
		System.out.println("Drawing Lines!!!!");
	}

	public void drawCircle() {
		System.out.println("Drawing Circles!!!!");
	}

	public void drawSquare() {
		System.out.println("Drawing Squares!!!!");
	}

}
