package com.example.prototype;

public class Client {
	
	public static void main(String[] args) {
		
		Movie movie1 = new Movie("Bahubali", 3, "Action");
		System.out.println(movie1);
		System.out.println(movie1.hashCode());
		
		try {
			Movie movie2 = (Movie) movie1.clone();
			System.out.println(movie2);
			System.out.println(movie2.hashCode());
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
	}

}
