package com.example.builder._2;

public class Client {
	
	public static void main(String[] args) {
		
		Car car1  = new Car.CarBuilder(100, "Audi", "Q5").build();
		System.out.println(car1);
		
		Car car2  = new Car.CarBuilder(100, "Audi", "Q5")
				.setPrice(12000.00)
				.setColor("Yellow")
				.setQty(10)
				.build();
		
		System.out.println(car2);
	
		Car car3 = new Car.CarBuilder(100, "Audi", "Q5")
				.setPrice(12000.00)
				.build();
		
		System.out.println(car3);

		Car car4 = new Car.CarBuilder(100, "Audi", "Q5")
				.setPrice(12000.00)
				.setColor("Black")
				.build();
		
		System.out.println(car4);

		Car car5 = new Car.CarBuilder(100, "Audi", "Q5")
				.setQty(12)
				.build();
		
		System.out.println(car5);
		
		Car car6 = new Car.CarBuilder(100, "Audi", "Q5")
				.setColor("Black")
				.build();
		
		System.out.println(car6);


		
		/*System.out.println(car);
		System.out.println(car.getVin());
		System.out.println(car.getMake());
		System.out.println(car.getModel());
		System.out.println(car.getPrice());
		System.out.println(car.getColor());
		System.out.println(car.getQty());*/
		
	}

}
