package com.example.java8.swk;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class OrderService {
	
	
	//FINALLY BEST : 
	//avoiding excessive method chaining by having meaningful variables (Stream Wrecks)
	//introduce meaningful variables
	public List<Car> getMostOrderedCars(List<Order> orders) {
		
		List<Integer> outdatedCarVins = CarDAO.getOutdatedCarVins();
	    Predicate<Car> carIsNotOutdated = car -> !outdatedCarVins.contains(car.getVin());
	      
	    Stream<Car> mostSoldCars = getSoldCarsCountOverTheLastYear(orders)
				.entrySet()
				.stream()
				.filter(entry -> entry.getValue() >= 50)
				.map(Entry::getKey);
		
	    return mostSoldCars.filter(Car::isHighprice)
				.filter(carIsNotOutdated)
				.collect(Collectors.toList());
	}

	
	//VERY GOOD : avoiding excessive method chaining by having meaningful variables (Stream Wrecks)
	public List<Car> getMostOrderedCarsVeryGood(List<Order> orders) {
		
		List<Integer> outdatedCarVins = CarDAO.getOutdatedCarVins();
	    Predicate<Car> carIsNotOutdated = car -> !outdatedCarVins.contains(car.getVin());
	      
		return 	getSoldCarsCountOverTheLastYear(orders)
				.entrySet()
				.stream()
				//take only the frequent ordered cars (>=50)
				.filter(entry -> entry.getValue() >= 50)
				//Consider only which are high priced
				.map(Entry::getKey)
				.filter(Car::isHighprice)
				//And not outdated as per car life 
				.filter(carIsNotOutdated)
				.collect(Collectors.toList());
	}
	
	//GOOD : avoiding excessive method chaining by having meaningful variables (Stream Wrecks)
	public List<Car> getMostOrderedCarsGood(List<Order> orders) {
		return 	getSoldCarsCountOverTheLastYear(orders)
				.entrySet()
				.stream()
				//take only the frequent ordered cars (>=50)
				.filter(entry -> entry.getValue() >= 50)
				//Consider only which are high priced
				.map(Entry::getKey)
				.filter(car -> car.getPrice() > 400000)
				//And not outdated as per car life 
				.filter(car -> !CarDAO.getOutdatedCarVins().contains(car.getVin()))
				.collect(Collectors.toList());
	}
	
	
	private Map<Car, Integer> getSoldCarsCountOverTheLastYear(List<Order> orders) {
        return orders.stream()
				//First count how many times cars were ordered during the previous year
				.filter(order -> order.getOrderDate().isAfter(LocalDate.now().minusYears(1)))
				.flatMap(order -> order.getOrderItems().stream())
				//Calculating each car quantity ordered
				.collect(Collectors.groupingBy(OrderItem::getCar, Collectors.summingInt(OrderItem::getQty)));
	}
	
	//BAD : too lengthy method chaining 
	public List<Car> getMostOrderedCarsBad(List<Order> orders) {
		return orders.stream()
				//First count how many times cars were ordered during the previous year
				.filter(order -> order.getOrderDate().isAfter(LocalDate.now().minusYears(1)))
				.flatMap(order -> order.getOrderItems().stream())
				//Calculating each car quantity ordered
				.collect(Collectors.groupingBy(OrderItem::getCar, Collectors.summingInt(OrderItem::getQty)))
				.entrySet()
				.stream()
				//take only the frequent ordered cars (>=50)
				.filter(entry -> entry.getValue() >= 50)
				//Consider only which are high priced
				.map(Entry::getKey)
				.filter(car -> car.getPrice() > 500000)
				//And not outdated as per car life 
				.filter(car -> !CarDAO.getOutdatedCarVins().contains(car.getVin()))
				.collect(Collectors.toList());
	}

}
