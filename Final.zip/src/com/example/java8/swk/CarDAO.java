package com.example.java8.swk;

import java.util.List;

public class CarDAO {

	public static List<Car> selectAll() {
		//DB call ---- TBD
		return null;
	}
	
	public static List<Integer> getOutdatedCarVins(){
		//DB call ---- TBD
		return null;
	}

}
