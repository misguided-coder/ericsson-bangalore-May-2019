package com.example.java8.swk;

public class Client {
	
	public static void main(String[] args) {
		
		OrderService orderService= new OrderService();
		
		orderService.getMostOrderedCars(null);
	}

}
