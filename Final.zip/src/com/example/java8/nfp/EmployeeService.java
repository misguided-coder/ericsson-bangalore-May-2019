package com.example.java8.nfp;

import java.util.List;
import java.util.stream.Collectors;

public class EmployeeService {

	private String convertToString(Employee employee) {
		StringBuilder builder = new StringBuilder();
		builder.append("Name => ");
		builder.append(employee.getName().toUpperCase());
		builder.append(" || Salary => ");
		builder.append(employee.getSalary());
		builder.append(" || Desig => ");
		builder.append(employee.getDesig().toUpperCase());
		return builder.toString();
	}

	// FINAL ===> Avoid very heavy lambda and use named/expressive functions
	public List<String> readAll() {
		return EmployeeDAO.selectAll().stream().map(EmployeeMapper::convertToString).collect(Collectors.toList());
	}

	// GOOD ===> Avoid very heavy lambda and use named/expressive functions
	public List<String> readAllGood() {
		return EmployeeDAO.selectAll().stream().map(this::convertToString).collect(Collectors.toList());
	}

	// BAD ===> Using very heavy lambda inline not good
	public List<String> readAllBad() {
		return EmployeeDAO.selectAll().stream().map((employee) -> {
			StringBuilder builder = new StringBuilder();
			builder.append("Name => ");
			builder.append(employee.getName().toUpperCase());
			builder.append(" || Salary => ");
			builder.append(employee.getSalary());
			builder.append(" || Desig => ");
			builder.append(employee.getDesig().toUpperCase());
			return builder.toString();
		}).collect(Collectors.toList());
	}

}
