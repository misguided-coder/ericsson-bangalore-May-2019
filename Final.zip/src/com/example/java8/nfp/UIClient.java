package com.example.java8.nfp;

import java.util.List;

public class UIClient {

	public static void main(String[] args) {
		
		EmployeeService employeeService = new EmployeeService();
		List<String> strings = employeeService.readAll();
		
		for(String value : strings) {
			System.out.println(value);
		}
		
	}
}
