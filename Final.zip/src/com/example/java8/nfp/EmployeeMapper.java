package com.example.java8.nfp;

public class EmployeeMapper {

	public static String convertToString(Employee employee) {
		StringBuilder builder = new StringBuilder();
		builder.append("Name => ");
		builder.append(employee.getName().toUpperCase());
		builder.append(" || Salary => ");
		builder.append(employee.getSalary());
		builder.append(" || Desig => ");
		builder.append(employee.getDesig().toUpperCase());
		return builder.toString();
	}
}
