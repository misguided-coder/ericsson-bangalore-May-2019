package com.example.java8.nfp;

import java.util.ArrayList;
import java.util.List;

public class EmployeeDAO {
		
	public static List<Employee> selectAll() {
		List<Employee> employees = new ArrayList<>();
		employees.add(new Employee(1, "Jaggu", 45000.00, "Terrorist", "Bombers", "Lahore", "Sindh Pakistan"));
		employees.add(new Employee(2, "Ganshu", 56000.00, "Terrorist", "Terror", "Karachi", "Punjab Pakistan"));
		employees.add(new Employee(3, "Kallu", 15000.00, "Goon", "Bombers", "Lahore", "Sindh Pakistan"));
		employees.add(new Employee(4, "Kali Charan", 89000.00, "Goon", "Secret", "Karachi", "Punjab Pakistan"));
		employees.add(new Employee(5, "Pintu", 34000.00, "Terrorist", "Terror", "Karachi", "Punjab Pakistan"));
		employees.add(new Employee(6, "Rose Gulabo", 38000.00, "Sardar", "Secret", "Lahore", "Sindh Pakistan"));
		employees.add(new Employee(7, "Chandu Patiala", 85000.00, "Terrorist", "Terror", "Karachi", "Punjab Pakistan"));
		employees.add(new Employee(8, "Mohini", 14000.00, "Jr. Thief", "Terror", "Karachi", "Punjab Pakistan"));
		employees.add(new Employee(9, "Kalu Khatharnak", 95000.00, "Goon", "Secret", "Lahore", "Sindh Pakistan"));
		employees.add(new Employee(10, "Rancho", 65000.00, "Sr. Thief", "Terror", "Hyderabad", "Sindh Pakistan"));
		employees.add(new Employee(11, "Gabbar Singh", 90000.00, "Terrorist", "Terror", "Lahore", "Sindh Pakistan"));
		employees.add(new Employee(12, "Johni Gaddar", 56000.00, "Goon", "Secret", "Hyderabad", "SindhPakistan"));
		employees.add(new Employee(13, "Ramu", 40000.00, "Terrorist", "Terror", "Lahore", "Sindh Pakistan"));
		employees.add(new Employee(14, "Laden Humble", 99000.00, "The Boss", "Bombers", "Hyderabad", "Sindh Pakistan"));
		employees.add(new Employee(15, "Dawood Boss", 25000.00, "The Boss", "Bombers", "Lahore", "Sindh Pakistan"));
		return employees;
	}

}
