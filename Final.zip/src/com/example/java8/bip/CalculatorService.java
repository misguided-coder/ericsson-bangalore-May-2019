package com.example.java8.bip;

//Developer A =====> API Designer
public class CalculatorService {

	public void calculate(int a,int b,Math math) {
		System.out.println("Doing internal work....");
		System.out.printf("CalculatorService Result : %s%n", math.doCal(a,b));
		System.out.println("Done....");
	}

}
