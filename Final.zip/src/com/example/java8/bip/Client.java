package com.example.java8.bip;

//Developer B ======> API Consumer/User
public class Client {

	public static void main(String[] args) {

		CalculatorService calculatorService = new CalculatorService();
		calculatorService.calculate(400,10,(a, b) -> a + b);
		calculatorService.calculate(400,10,(a, b) -> a * b);
		calculatorService.calculate(400,10,(a, b) -> a / b);
		calculatorService.calculate(400,10,(a, b) -> a - b);
		calculatorService.calculate(400,10,(a, b) -> a % b);
		calculatorService.calculate(400,10,(a, b) -> a + a + b);
		calculatorService.calculate(400,10,(a, b) -> a * a + b);
		calculatorService.calculate(400,10,(a, b) -> a - a + b);
		calculatorService.calculate(400,10,(a, b) -> a / a + b + a);
		
	}

}
