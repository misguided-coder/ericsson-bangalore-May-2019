package com.example.java8.bip;

public interface Math {
	public int doCal(int arg1,int arg2);
}
