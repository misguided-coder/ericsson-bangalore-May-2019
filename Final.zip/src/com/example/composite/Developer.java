package com.example.composite;

public class Developer extends Component {

	@Override
	public void updateSalary(double basicSalary) {
		System.out.printf("Developer Updated Salary is : %s%n",(basicSalary+basicSalary *.02));
	}

	
	@Override
	public void applyForLeave() {
		System.out.println("Developer applied for 2 days sick leave!!!!");
	}
	
	@Override
	public void assignProject() {
		System.out.println("Developer assigned 2 projects!!!!");
	}
}
