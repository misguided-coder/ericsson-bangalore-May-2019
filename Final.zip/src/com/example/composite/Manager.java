package com.example.composite;

public class Manager extends Component {

	@Override
	public void updateSalary(double basicSalary) {
		System.out.printf("Manager Updated Salary is : %s%n",(basicSalary+basicSalary *.20));
	}

	
	@Override
	public void applyForLeave() {
		System.out.println("Manager applied for 2 year long holiday leave!!!!");
	}
	
	@Override
	public void assignProject() {
		System.out.println("Manager assigned project to 10 members!!!!");
	}
}
