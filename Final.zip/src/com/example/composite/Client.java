package com.example.composite;

public class Client {

	public static void main(String[] args) {

		Component manager1 = new Manager();
		Component manager2 = new Manager();

		manager1.add(new Developer());
		manager1.add(new Developer());
		manager1.add(new Developer());
		manager1.add(manager2);

		manager2.add(new Developer());
		manager2.add(new Developer());
		manager2.add(new Developer());

		manager1.applyForLeave();
		manager2.applyForLeave();
		System.out.println("============================");

		iterate(manager1);
	}

	private static void iterate(Component component) {
		for (Component currentComponent : component.getAll()) {
			if (currentComponent.getAll().size() > 0) {
				iterate(currentComponent);
			}
			currentComponent.applyForLeave();
			currentComponent.assignProject();
			currentComponent.updateSalary(200000.00);
			System.out.println("============================");
		}

	}

}
