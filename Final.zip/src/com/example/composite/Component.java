package com.example.composite;

import java.util.ArrayList;
import java.util.List;

public abstract class Component {

	List<Component> components = new ArrayList<>();
		
	public void add(Component component) {
		components.add(component);
	}
	
	public void remove(Component component) {
		components.remove(component);
	}
	
	public Component get(int idx) {
		return components.get(idx);
	}
	
	public List<Component> getAll() {
		return components;
	}
	
	public abstract void updateSalary(double basicSalary);
	public abstract void applyForLeave();
	public abstract void assignProject();
	
	public void calculateTDS(double basicSalary) {
		System.out.printf("TDS : %s%n",basicSalary*.30);
	}

}
