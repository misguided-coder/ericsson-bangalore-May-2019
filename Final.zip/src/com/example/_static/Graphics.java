package com.example._static;

public class Graphics {

	public static void drawLine() {
		System.out.println("Drawing Lines!!!!");
	}

	public static void drawCircle() {
		System.out.println("Drawing Circles!!!!");
	}

	public static void drawSquare() {
		System.out.println("Drawing Squares!!!!");
	}

}
