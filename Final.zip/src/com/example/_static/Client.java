package com.example._static;

public class Client {

	public static void main(String[] args) throws Exception {
		
		// Developer A
		Graphics.drawCircle();

		// Developer B
		Graphics.drawSquare();

		// Developer C
		Graphics.drawLine();
		Graphics.drawSquare();
	}
}
