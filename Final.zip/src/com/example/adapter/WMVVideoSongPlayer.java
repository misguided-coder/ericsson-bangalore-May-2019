package com.example.adapter;

public class WMVVideoSongPlayer implements VideoSongPlayer {

	public void playVideoSong(String mediaName) {
		System.out.printf("WMVVideoSongPlayer =====>  playing %s video song!!!!%n",mediaName);
	}

}
