package com.example.adapter;

public interface VideoSongPlayer {

	public void playVideoSong(String mediaName);

}
