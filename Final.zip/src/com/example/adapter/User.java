package com.example.adapter;

public class User {

	public static void main(String[] args) {
		
		MusicPlayer musicPlayer = new MP3MusicPlayer();
		musicPlayer.playSong("KGF Title");
		musicPlayer.stop();
		
		musicPlayer = new MusicAdapter(new MP4VideoSongPlayer());
		musicPlayer.playSong("Bahubali Title");
		musicPlayer.stop();
	
		musicPlayer = new MusicAdapter(new WMVVideoSongPlayer());
		musicPlayer.playSong("Robot Title");
		musicPlayer.stop();
	
		//VideoSongPlayer videoSongPlayer = new MP4VideoSongPlayer();
		//videoSongPlayer.playVideoSong("Bahubali Title");
		
	}
	
	
	
}
