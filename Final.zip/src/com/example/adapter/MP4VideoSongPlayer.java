package com.example.adapter;

public class MP4VideoSongPlayer implements VideoSongPlayer {

	public void playVideoSong(String mediaName) {
		System.out.printf("MP4VideoSongPlayer =====>  playing %s video song!!!!%n",mediaName);
	}

}
