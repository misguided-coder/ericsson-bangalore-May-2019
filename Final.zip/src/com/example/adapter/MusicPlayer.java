package com.example.adapter;

public interface MusicPlayer {

	public void playSong(String mediaName);
	public void stop();

}
