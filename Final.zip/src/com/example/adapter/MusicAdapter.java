package com.example.adapter;

public class MusicAdapter implements MusicPlayer {

	VideoSongPlayer videoSongPlayer = null;
	
	public MusicAdapter(VideoSongPlayer videoSongPlayer) {
		this.videoSongPlayer = videoSongPlayer;
	}
	
	@Override
	public void playSong(String mediaName) {
		System.out.println("MusicAdapter ====> playing!!!!!");
		this.videoSongPlayer.playVideoSong(mediaName);
	}
	
	@Override
	public void stop() {
		System.out.println("MusicAdapter ====> stopping!!!!!");
	}

}
