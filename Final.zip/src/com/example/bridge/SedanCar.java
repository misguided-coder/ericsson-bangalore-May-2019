package com.example.bridge;

public class SedanCar extends Car {
	
	public SedanCar(Automobile automobile) {
		super(automobile);
	}
	
	public void make() {
		System.out.println("Sedan car material is ready!!!!!");
		this.automobile.manufacture();
	}
	
	public void polish() {
		System.out.println("Sedan car paint and machines are ready!!!!!");
		this.automobile.paint();
	}
}
