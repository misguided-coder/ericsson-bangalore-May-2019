package com.example.bridge;

public class Client {
	
	public static void main(String[] args) throws Exception {
	
		LuxuryCar luxuryCar = new LuxuryCar(CarManager.getAutomobileVendor());
		
		luxuryCar.make();
		luxuryCar.polish();
		
	}

}
