package com.example.bridge;

public class LuxuryCar extends Car {
	
	public LuxuryCar(Automobile automobile) {
		super(automobile);
	}
	
	public void make() {
		System.out.println("Luxury car material is ready!!!!!");
		this.automobile.manufacture();
	}
	
	public void polish() {
		System.out.println("Luxury car paint and machines are ready!!!!!");
		this.automobile.paint();
	}
}
