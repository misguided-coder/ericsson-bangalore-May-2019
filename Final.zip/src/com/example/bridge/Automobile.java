package com.example.bridge;

public interface Automobile {
	
	public void manufacture();
	public void paint();
	
}
