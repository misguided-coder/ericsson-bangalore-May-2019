package com.example.bridge;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class CarManager {

	static Properties properties = null;

	static {
		try {
			properties = new Properties();
			properties.load(new FileReader("src/com/example/bridge/car-vendor.properties"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static Automobile getAutomobileVendor() {
		try {
			Class class1 = Class.forName(properties.getProperty("car.vendor"));
			return (Automobile) class1.newInstance();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
