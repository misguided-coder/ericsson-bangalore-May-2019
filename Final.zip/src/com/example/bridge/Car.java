package com.example.bridge;

public abstract class Car {

	Automobile automobile;

	public Car(Automobile automobile) {
		this.automobile = automobile;
	}

	public abstract void make();

	public abstract void polish();
}
