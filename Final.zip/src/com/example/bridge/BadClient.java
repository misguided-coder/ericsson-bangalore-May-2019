package com.example.bridge;

import com.example.bridge.jaguar.impl.JaguarLuxuryCar;
import com.example.bridge.jaguar.impl.JaguarSedanCar;

public class BadClient {
	
	public static void main(String[] args) {
			
		
		LuxuryCar luxuryCar = new LuxuryCar(new JaguarLuxuryCar());
		
		luxuryCar.make();
		luxuryCar.polish();
		
		SedanCar sedanCar = new SedanCar(new JaguarSedanCar());
		
		sedanCar.make();
		sedanCar.polish();
		
		
		
	}

}
