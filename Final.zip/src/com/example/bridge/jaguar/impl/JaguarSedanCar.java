package com.example.bridge.jaguar.impl;

import com.example.bridge.Automobile;

public class JaguarSedanCar implements Automobile {
	
	@Override
	public void manufacture() {
		System.out.println("Jaguar is preparing items to make Sedan Car.");
		System.out.println("Jaguar is preparing right place to make Sedan Car.");
		System.out.println("Jaguar is ready with Sedan Car.");
	}
	
	@Override
	public void paint() {
		System.out.println("Jaguar is preparing items to paint Sedan Car.");
		System.out.println("Jaguar is preparing right place to paint Sedan Car.");
		System.out.println("Jaguar is ready with complete painted Sedan Car.");
	}

}
