package com.example.bridge.jaguar.impl;

import com.example.bridge.Automobile;

public class JaguarLuxuryCar implements Automobile {
	
	@Override
	public void manufacture() {
		System.out.println("Jaguar is preparing items to make Luxury Car.");
		System.out.println("Jaguar is preparing right place to make Luxury Car.");
		System.out.println("Jaguar is ready with Luxury Car.");
	}
	
	@Override
	public void paint() {
		System.out.println("Jaguar is preparing items to paint Luxury Car.");
		System.out.println("Jaguar is preparing right place to paint Luxury Car.");
		System.out.println("Jaguar is ready with complete painted Luxury Car.");
	}

}
