package com.example.bridge.audi.impl;

import com.example.bridge.Automobile;

public class AudiSedanCar implements Automobile {
	
	@Override
	public void manufacture() {
		System.out.println("Audi is preparing items to make Sedan Car.");
		System.out.println("Audi is preparing right place to make Sedan Car.");
		System.out.println("Audi is ready with Sedan Car.");
	}
	
	@Override
	public void paint() {
		System.out.println("Audi is preparing items to paint Sedan Car.");
		System.out.println("Audi is preparing right place to paint Sedan Car.");
		System.out.println("Audi is ready with complete painted Sedan Car.");
	}

}
