package com.example.bridge.audi.impl;

import com.example.bridge.Automobile;

public class AudiLuxuryCar implements Automobile {
	
	@Override
	public void manufacture() {
		System.out.println("Audi is preparing items to make Luxury Car.");
		System.out.println("Audi is preparing right place to make Luxury Car.");
		System.out.println("Audi is ready with Luxury Car.");
	}
	
	@Override
	public void paint() {
		System.out.println("Audi is preparing items to paint Luxury Car.");
		System.out.println("Audi is preparing right place to paint Luxury Car.");
		System.out.println("Audi is ready with complete painted Luxury Car.");
	}

}
