package com.example.factory._3;

public class Laptop {

}
