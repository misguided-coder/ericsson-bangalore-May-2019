package com.example.factory._3;

public class ObjectFactory {

	public static Employee createEmployee() {
		return new Employee();
	}

	public static Laptop createLaptop() {
		return new Laptop();
	}

	public static Car createCar() {
		return new Car();
	}

	public static Student createStudent() {
		return new Student();
	}

	public static Pizza createPizza() {
		return new Pizza();
	}
}
