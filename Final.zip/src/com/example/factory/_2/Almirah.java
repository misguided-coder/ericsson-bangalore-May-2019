package com.example.factory._2;

public class Almirah extends Furniture {

	@Override
	public void make() {
		System.out.printf("Almirah is made of %s%n",this.material);
	}
	
	@Override
	public void paint() {
		System.out.println("Almirah is painted by hand machine!!!");
	}
	
	@Override
	public void sell() {
		System.out.println("Almirah is sold - Rs. 8900000 only!!!!");	
	}
	
}
