package com.example.factory._2;

public abstract class Furniture {
	
	int id;
	String material = "Wood";
	
	public void info() {
		System.out.printf("ID : %s%n",this.id);
		System.out.printf("Material : %s%n",this.material);
	}
	
	public abstract void make();
	public abstract void paint();
	public abstract void sell();
}
