package com.example.factory._1;

public class LaptopFactory {

	public static Laptop createInstance() {
		return new Laptop("RE34Y6","Dell","Inspiron",70000.00);
	}
}
