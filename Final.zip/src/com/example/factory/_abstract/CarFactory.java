package com.example.factory._abstract;

public class CarFactory {

	public static Car createCar(CarType carType, String location) {
		Car car = null;
		switch (location) {
		case "Pune":
			car = PuneCarFactory.createCar(carType);
			break;
		case "Calcutta":
			car = CalcuttaCarFactory.createCar(carType);
			break;
		}
		return car;
	}
}
