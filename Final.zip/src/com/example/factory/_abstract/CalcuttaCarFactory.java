package com.example.factory._abstract;

public class CalcuttaCarFactory {
	
	public static Car createCar(CarType carType) {
		Car car = null;
		switch (carType) {
		case LUXURY:
			car = new LuxuryCar("Calcutta City");
			break;

		case SEDAN:
			car = new SedanCar("Calcutta City");
			break;
		}
		return car;
	}
}
