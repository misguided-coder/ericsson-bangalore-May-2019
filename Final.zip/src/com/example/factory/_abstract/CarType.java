package com.example.factory._abstract;

public enum CarType {
	LUXURY,SEDAN
}
