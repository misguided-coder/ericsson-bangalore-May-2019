package com.example.factory._abstract;

public abstract class Car {

	String location;

	public Car(String location) {
		this.location = location;
	}

	public abstract void speedUp();

	public abstract void speedDown();
}
