package com.example.factory._abstract;

public class SedanCar extends Car {
	
	public SedanCar(String location) {
		super(location);
		System.out.printf("SedanCar is available in : %s%n",this.location);
	}

	@Override
	public void speedUp() {
		System.out.println("SedanCar is speeding up!!!!");
	}

	@Override
	public void speedDown() {
		System.out.println("SedanCar is slowing down!!!!");
	}
}
