package com.example.factory._abstract;

public class PuneCarFactory {
	
	public static Car createCar(CarType carType) {
		Car car = null;
		switch (carType) {
		case LUXURY:
			car = new LuxuryCar("Pune City");
			break;

		case SEDAN:
			car = new SedanCar("Pune City");
			break;
		}
		return car;
	}
}
