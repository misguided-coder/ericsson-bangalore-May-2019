package com.example.proxy.protection;

import java.util.Arrays;
import java.util.List;

public class EmailServiceProxy implements EmailService {
	
	EmailService originalEmailService;
	List<String> blockedServers = null;
	
	public EmailServiceProxy() {
		originalEmailService = new EmailServiceImpl();
		blockedServers = Arrays.asList("bjp.com","bsp.com","msn.com");
	}
	
	@Override
	public void send(String to) {
		boolean serverBlocked = false;
		System.out.println("Protection Proxy is in use!!!!!!!");
		for(String blockedServer : blockedServers) {
			if(to.contains(blockedServer)) {
				serverBlocked = true;
				break;
			}
		}
		if(!serverBlocked) {
			originalEmailService.send(to);
		} else {
			System.out.printf("%s mail domain is blocked by proxy!!!!%n",to);
		}
	}
	
}
