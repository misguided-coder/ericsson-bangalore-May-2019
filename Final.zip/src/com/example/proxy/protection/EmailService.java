package com.example.proxy.protection;

public interface EmailService {
	public void send(String to);
}
