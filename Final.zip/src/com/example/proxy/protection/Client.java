package com.example.proxy.protection;

public class Client {

	public static void main(String[] args) {
		
		EmailService emailService = new EmailServiceProxy();
	
		emailService.send("billgates@msn.com");
		emailService.send("modi@bjp.com");
		emailService.send("mayawati@bsp.com");
		emailService.send("obama@gmail.com");
		
	}
}
