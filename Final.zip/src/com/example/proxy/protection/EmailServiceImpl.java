package com.example.proxy.protection;

public class EmailServiceImpl implements EmailService {
	
	@Override
	public void send(String to) {
		System.out.printf("Mail is sent to : %s!!!!%n",to);
	}
	
}
