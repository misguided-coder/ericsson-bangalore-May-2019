package com.example.builder._2;

public class Car {

	// Required fields
	int vin;
	String make;
	String model;

	// Optional fields
	double price;
	String color;
	int qty;

	private Car(CarBuilder builder) {
		this.vin = builder.vin;
		this.make = builder.make;
		this.model = builder.model;
		this.price = builder.price;
		this.color = builder.color;
		this.qty = builder.qty;
	}

	public int getVin() {
		return vin;
	}

	public String getMake() {
		return make;
	}

	public String getModel() {
		return model;
	}

	public double getPrice() {
		return price;
	}

	public String getColor() {
		return color;
	}

	public int getQty() {
		return qty;
	}
	
	@Override
	public String toString() {
		return "Car [vin=" + vin + ", make=" + make + ", model=" + model + ", price=" + price + ", color=" + color
				+ ", qty=" + qty + "]";
	}

	public static class CarBuilder {
		
		// Required fields
		int vin;
		String make;
		String model;

		// Optional fields
		double price;
		String color;
		int qty;
		
		public CarBuilder(int vin, String make, String model) {
			this.vin = vin;
			this.make = make;
			this.model = model;
		}
		
		public CarBuilder setVin(int vin) {
			this.vin = vin;
			return this;
		}
		public CarBuilder setMake(String make) {
			this.make = make;
			return this;
		}
		public CarBuilder setModel(String model) {
			this.model = model;
			return this;
		}
		public CarBuilder setPrice(double price) {
			this.price = price;
			return this;
		}
		public CarBuilder setColor(String color) {
			this.color = color;
			return this;
		}
		public CarBuilder setQty(int qty) {
			this.qty = qty;
			return this;
		}
		
		public Car build() {
			return new Car(this);
		}
	}
	
}
