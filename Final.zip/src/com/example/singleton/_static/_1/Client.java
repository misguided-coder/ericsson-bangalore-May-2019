package com.example.singleton._static._1;

public class Client {

	public static void main(String[] args) {
		
		//Developer A
		//Graphics graphics1 = new Graphics();
		Graphics graphics1 = Graphics.instance();
		graphics1.drawCircle();
		System.out.println(graphics1.hashCode());
		System.out.println(graphics1);
		
		
		//Developer B
		//Graphics graphics2 = new Graphics();
		Graphics graphics2 = Graphics.instance();
		graphics2.drawSquare();
		System.out.println(graphics2.hashCode());
		System.out.println(graphics2);
		
		//Developer C
		//Graphics graphics3 = new Graphics();
		Graphics graphics3 = Graphics.instance();
		graphics3.drawLine();
		graphics3.drawSquare();
		System.out.println(graphics3.hashCode());
		System.out.println(graphics3);
		
		System.out.println(graphics1 == graphics2);
		System.out.println(graphics2 == graphics3);

		
	}
}
