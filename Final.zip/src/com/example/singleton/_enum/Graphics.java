package com.example.singleton._enum;

//Static way of creating Singleton
//Eager singleton creation
public enum Graphics {
	
	instance;
	
	public void drawLine() {
		System.out.println("Drawing Lines!!!!");
	}

	public void drawCircle() {
		System.out.println("Drawing Circles!!!!");
	}

	public void drawSquare() {
		System.out.println("Drawing Squares!!!!");
	}

}
