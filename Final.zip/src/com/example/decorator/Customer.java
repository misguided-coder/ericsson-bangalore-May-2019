package com.example.decorator;

public class Customer {
	
	public static void main(String[] args) {
		
		//Jahid
		Pizza pizza1 = new TomatoToppings(new TomatoToppings(new TomatoToppings(new TomatoToppings(new CheeseBrustPizza()))));
		System.out.println(pizza1.prepare());
		
		//Ramesh
		Pizza pizza2 = new ChilliToppings(new ChilliToppings(new OnionToppings(new CheeseBrustPizza()))); 
		System.out.println(pizza2.prepare());
		
		
	}

}
