package com.example.decorator;

public class CheeseBrustPizza extends Pizza {

	@Override
	public String prepare() {
		return super.prepare() + " with CheeseBrust Base";
	}
}
