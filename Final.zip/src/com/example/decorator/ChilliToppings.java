package com.example.decorator;

public class ChilliToppings extends Pizza {

	Pizza originalPizaa;

	public ChilliToppings(Pizza originalPizaa) {
		this.originalPizaa = originalPizaa;
	}

	@Override
	public String prepare() {
		return this.originalPizaa.prepare() + addChillis();
	}
	
	public String addChillis() {
		return " with Chillis";
	}
}
