package com.example.decorator;

public class Pizza {
	
	public String prepare() {
		return "Preparing Pizza ";
	}
}
