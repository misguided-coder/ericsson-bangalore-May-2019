package com.example.facade;

public class CustomerService {

	public void updateEmail() {
		System.out.println("Updating email....");
	}
	
	public void updatePhone() {
		System.out.println("Updating phone....");
	}

}
