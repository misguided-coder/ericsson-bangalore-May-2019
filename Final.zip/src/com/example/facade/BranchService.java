package com.example.facade;

public class BranchService {

	public void open(AccountService accountService) {
		System.out.println("Opening account...."+accountService.getClass().getName());
	}
	
	public void close() {
		System.out.println("Closing account....");
	}
	
	public void transfer() {
		System.out.println("Transfering account....");
	}
	
	
}
