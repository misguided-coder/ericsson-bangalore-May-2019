package com.example.facade;

public class AccountService {

	public void withdraw() {
		System.out.println("Withdrawing money....");
	}
	
	public void deposit() {
		System.out.println("Depositing money....");
	}
	
	public double balance() {
		System.out.println("Showing balance....");
		return 10000000.00;
	}
	
	
}
