package com.example.facade;

public class CurrentAccountService extends AccountService {

	public void withdraw() {
		System.out.println("CurrentAccountService Withdrawing money....");
	}
	
	public void deposit() {
		System.out.println("CurrentAccountService Depositing money....");
	}
	
	public double balance() {
		System.out.println("CurrentAccountService Showing balance....");
		return 66000000.00;
	}
	
	
}
