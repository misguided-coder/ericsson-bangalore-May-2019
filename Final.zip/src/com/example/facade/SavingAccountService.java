package com.example.facade;

public class SavingAccountService extends AccountService {

	public void withdraw() {
		System.out.println("SavingAccountService Withdrawing money....");
	}
	
	public void deposit() {
		System.out.println("SavingAccountService Depositing money....");
	}
	
	public double balance() {
		System.out.println("SavingAccountService Showing balance....");
		return 10000000.00;
	}
	
	
}
