package com.example.facade;

public class EmailService {

	public void send() {
		System.out.println("Notification sent to customer using Email....");
	}
	
}
