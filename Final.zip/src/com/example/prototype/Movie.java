package com.example.prototype;

public class Movie implements Cloneable {

	String title;
	int length; // hours
	String type;
	Song song;

	public Movie(String title, int length, String type, Song song) {

		System.out.println("Inside Movie constructor()!!!!!!");
		this.title = title;
		this.length = length;
		this.type = type;
		this.song = song;
		// 50 loc
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Song getSong() {
		return song;
	}

	public void setSong(Song song) {
		this.song = song;
	}

	@Override
	public String toString() {
		return "Movie [title=" + title + ", length=" + length + ", type=" + type + ", song=" + song + "]";
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		System.out.println("Making a copy of original/prototype!!!!");
		//Write full movie object in a file
		//Read it back from file
		return super.clone();
	}

}
