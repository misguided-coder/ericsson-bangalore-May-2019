package com.example.prototype;

public class Song {

	String name;
	String singer;
	int length;

	public Song() {

	}

	public Song(String name, String singer, int length) {
		this.name = name;
		this.singer = singer;
		this.length = length;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSinger() {
		return singer;
	}

	public void setSinger(String singer) {
		this.singer = singer;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	@Override
	public String toString() {
		return "Song [name=" + name + ", singer=" + singer + ", length=" + length + "]";
	}

}
